<?php


/**
 * Class Loader
 *
 *
 * The actual Methods and Properties of the Loader class
 *
 * @property $registry
 *
 * @method library
 * @method helper
 * @method model
 * @method database
 * @method config
 * @method language
 *
 */
class Loader
{
}

// End loader.php